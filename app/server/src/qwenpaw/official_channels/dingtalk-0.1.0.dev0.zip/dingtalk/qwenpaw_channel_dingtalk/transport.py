# -*- coding: utf-8 -*-
# pylint: disable=too-many-statements,too-many-branches
# pylint: disable=too-many-return-statements,unused-argument
"""DingTalk Webhook/card/media transport shared by Channel and child Driver."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import mimetypes
import os
import threading
import time
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
)
from uuid import uuid4
from urllib.parse import unquote, urlparse


import aiohttp
from qwenpaw.app.channels.utils import split_text
from qwenpaw.config.utils import get_config_path
from qwenpaw.constant import DEFAULT_MEDIA_DIR
from qwenpaw.exceptions import ChannelError

from qwenpaw.schemas import ContentType


from .constants import (
    AI_CARD_PROCESSING_TEXT,
    AI_CARD_RECOVERY_FINAL_TEXT,
)
from .content_utils import parse_data_url, session_param_from_webhook_url
from . import markdown as dingtalk_markdown
from .ai_card import (
    FAILED,
    FINISHED,
    PROCESSING,
    AICardPendingStore,
    ActiveAICard,
)

from .platform import DingTalkPlatform, owned_io

if TYPE_CHECKING:
    from qwenpaw.schemas import (
        AudioContent,
        FileContent,
        ImageContent,
        RefusalContent,
        TextContent,
        VideoContent,
    )

    OutgoingContentPart = (
        AudioContent
        | FileContent
        | ImageContent
        | RefusalContent
        | TextContent
        | VideoContent
    )


logger = logging.getLogger(__name__)

# DingTalk markdown is capped near 5000 chars. 3500 matches the
# historical safe budget; longer bodies are split below that so each
# piece still sends as markdown (GFM tables stay renderable).
_MARKDOWN_SAFE_LEN = 3500
_MARKDOWN_CHUNK_LEN = 3000


def _markdown_chunks(text: str) -> List[str]:
    """Split oversized DingTalk markdown into renderable chunks.

    Bodies within the markdown-safe budget are returned unchanged.
    Longer bodies go through ``split_text`` so GFM tables repeat their
    header on every chunk instead of the message dropping to plain text.
    """
    if len(text) <= _MARKDOWN_SAFE_LEN:
        return [text]
    chunks = split_text(text, max_len=_MARKDOWN_CHUNK_LEN)
    if not chunks:
        return [text]
    logger.info(
        "dingtalk markdown split: text_len=%s chunks=%s",
        len(text),
        len(chunks),
    )
    return chunks


class DingTalkTransport(DingTalkPlatform):
    """Reusable SDK/Webhook/media transport; no Agent or BaseChannel."""

    channel = "dingtalk"

    def initialize(self, config):
        """Prepare instance-owned transport without host orchestration."""
        message_type = config.get("message_type", "markdown")
        cron_message_type = config.get("cron_message_type", "markdown")
        card_template_id = config.get("card_template_id", "")
        card_template_key = config.get("card_template_key", "content")
        robot_code = config.get("robot_code", "")
        media_dir = config.get("media_dir", "")
        workspace_dir = config.get("workspace_dir", None)
        require_mention = config.get("require_mention", False)
        card_auto_layout = config.get("card_auto_layout", False)
        at_sender_on_reply = config.get("at_sender_on_reply", False)
        endpoint = config.get("endpoint", "")
        share_session_in_group = config.get("share_session_in_group", False)
        enabled = config.get("enabled", True)
        client_id = config.get("client_id", "")
        client_secret = config.get("client_secret", "")
        bot_prefix = config.get("bot_prefix", "")
        self.require_mention = require_mention
        self.enabled = enabled
        self.client_id = client_id
        self.client_secret = client_secret
        self.bot_prefix = bot_prefix
        self.message_type = (message_type or "markdown").strip().lower()
        self.cron_message_type = (
            (cron_message_type or "markdown").strip().lower()
        )
        self.card_template_id = card_template_id or ""
        self.card_template_key = card_template_key or "content"
        self.robot_code = robot_code or self.client_id
        self.card_auto_layout = card_auto_layout
        self.at_sender_on_reply = at_sender_on_reply
        self.share_session_in_group = share_session_in_group
        self.endpoint = (endpoint or "").strip().rstrip("/")
        self._workspace_dir = (
            Path(workspace_dir).expanduser() if workspace_dir else None
        )
        self._active_cards: Dict[str, ActiveAICard] = {}
        self._active_cards_lock = asyncio.Lock()
        cards_dir = self._workspace_dir or get_config_path().parent
        self._card_store = AICardPendingStore(
            cards_dir / "dingtalk-active-cards.json",
        )
        # Use workspace-specific media dir if workspace_dir is provided
        if not media_dir and self._workspace_dir:
            self._media_dir = self._workspace_dir / "media"
        elif media_dir:
            self._media_dir = Path(media_dir).expanduser()
        else:
            self._media_dir = DEFAULT_MEDIA_DIR

        self._client: Any = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._stream_event_loop: Optional[asyncio.AbstractEventLoop] = None
        self._stream_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._active = False
        self._state = "stopped"
        self._last_error = None
        self._lifecycle_lock = asyncio.Lock()
        self._cleanup_task = None
        self._pending_io = set()
        self._generation = 0
        self._sdk = None
        self._http: Optional[aiohttp.ClientSession] = None

        # DingTalk OpenAPI SDK clients
        self._oauth_sdk: Any = None
        self._robot_sdk: Any = None
        self._card_sdk: Any = None

        # Store sessionWebhook for proactive send (in-memory).
        # Key is a handle string, e.g. "dingtalk:sw:<sender>"
        # Value is a dict: {"webhook": str, "conversation_id": str, ...}
        self._session_webhook_store: Dict[str, Any] = {}
        self._session_webhook_lock = asyncio.Lock()

        # Time debounce disabled: manager drains same-session from queue
        # and merges before calling us.
        self._debounce_seconds = 0.0

        # Token cache (instance-level for multi-instance / tests)
        self._token_lock = asyncio.Lock()
        self._token_value: Optional[str] = None
        self._token_expires_at: float = 0.0

        # Dedup: in-flight message_ids only (message_id is sufficient).
        self._processing_message_ids: set = set()
        self._processing_message_ids_lock = threading.Lock()

        if not hasattr(self, "_debounce_timers"):
            self._debounce_timers = {}
            self._debounce_pending = {}

    def _route_from_handle(self, to_handle: str) -> dict:
        # to_handle:
        # - "dingtalk:sw:<sender>" -> use stored webhook by key
        # - "dingtalk:webhook:<url>" -> direct webhook URL
        # - "<url>" (starts with http/https) -> direct webhook URL
        s = (to_handle or "").strip()
        if s.startswith("http://") or s.startswith("https://"):
            return {"session_webhook": s}

        parts = s.split(":", 2)
        if len(parts) == 3 and parts[0] == "dingtalk":
            kind, ident = parts[1], parts[2]
            if kind == "sw":
                return {"webhook_key": f"dingtalk:sw:{ident}"}
            if kind == "webhook":
                return {"session_webhook": ident}
        return {"webhook_key": s} if s else {}

    def _session_webhook_store_path(self) -> Path:
        """Path to persist session webhook mapping (for cron after restart).

        Uses agent workspace directory if available, otherwise falls back
        to global config directory for backward compatibility.
        """
        if self._workspace_dir:
            return self._workspace_dir / "dingtalk_session_webhooks.json"
        return get_config_path().parent / "dingtalk_session_webhooks.json"

    def _load_session_webhook_store_from_disk(self) -> None:
        """Load session webhook mapping from disk into memory."""
        path = self._session_webhook_store_path()
        if not path.is_file():
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    # Support both old format (plain string) and new format
                    # (dict with webhook, expired_time, etc.)
                    # Load any dict entry even if webhook is empty, because
                    # conversation_id etc. are needed for Open API fallback.
                    if isinstance(v, str) and v:
                        self._session_webhook_store[k] = {"webhook": v}
                    elif isinstance(v, dict):
                        self._session_webhook_store[k] = v
        except (TimeoutError, aiohttp.ClientConnectionError):
            raise
        except Exception:
            logger.debug(
                "dingtalk load session_webhook store from %s failed",
                path,
                exc_info=True,
            )

    def _save_session_webhook_store_to_disk(self) -> None:
        """Persist in-memory session webhook store to disk."""
        path = self._session_webhook_store_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(
                    self._session_webhook_store,
                    f,
                    indent=2,
                    ensure_ascii=False,
                )
        except (TimeoutError, aiohttp.ClientConnectionError):
            raise
        except Exception:
            logger.debug(
                "dingtalk save session_webhook store to %s failed",
                path,
                exc_info=True,
            )

    async def _save_session_webhook(
        self,
        webhook_key: str,
        session_webhook: str,
        conversation_id: Optional[str] = None,
        conversation_type: Optional[str] = None,
        sender_staff_id: Optional[str] = None,
    ) -> None:
        if not webhook_key or not session_webhook:
            logger.debug(
                "dingtalk _save_session_webhook skip: key=%s has_url=%s",
                bool(webhook_key),
                bool(session_webhook),
            )
            return
        session_in_url = session_param_from_webhook_url(session_webhook)
        logger.info(
            "dingtalk _save_session_webhook: "
            "webhook_key=%s session_from_url=%s "
            "conversation_id=%s "
            "conversation_type=%s sender_staff_id=%s",
            webhook_key,
            session_in_url,
            conversation_id,
            conversation_type,
            sender_staff_id,
        )
        async with self._session_webhook_lock:
            self._session_webhook_store[webhook_key] = {
                "webhook": session_webhook,
                "conversation_id": conversation_id,
                "conversation_type": conversation_type,
                "sender_staff_id": sender_staff_id,
            }
            self._save_session_webhook_store_to_disk()

    async def _invalidate_session_webhook(self, to_handle: str) -> None:
        """Clear webhook in memory and disk after send failure.

        Keeps conversation_id and other metadata so Open API fallback
        still works on subsequent sends without a redundant failed POST.
        """
        route = self._route_from_handle(to_handle)
        webhook_key = route.get("webhook_key")
        if not webhook_key:
            return
        async with self._session_webhook_lock:
            raw = self._session_webhook_store.get(webhook_key)
            # Fallback to suffix-only key
            actual_key = webhook_key
            if raw is None:
                fallback_key = self._suffix_only_webhook_key(webhook_key)
                if fallback_key:
                    raw = self._session_webhook_store.get(fallback_key)
                    if raw is not None:
                        actual_key = fallback_key
            if raw is None:
                return
            entry = raw if isinstance(raw, dict) else {"webhook": raw}
            if not entry.get("webhook"):
                return
            logger.info(
                "dingtalk _invalidate_session_webhook: "
                "clearing webhook for key=%s",
                actual_key,
            )
            entry["webhook"] = ""
            self._session_webhook_store[actual_key] = entry
            self._save_session_webhook_store_to_disk()

    async def _load_session_webhook(self, webhook_key: str) -> Optional[str]:
        if not webhook_key:
            logger.debug("dingtalk _load_session_webhook: empty webhook_key")
            return None
        entry = await self._load_session_webhook_entry(webhook_key)
        if entry is not None:
            return entry.get("webhook")
        return None

    @staticmethod
    def _suffix_only_webhook_key(webhook_key: str) -> Optional[str]:
        """Extract suffix-only fallback key from a user-prefixed key.

        e.g. "dingtalk:sw:user123_tru1C1k=" -> "dingtalk:sw:tru1C1k="
        Returns None if the key has no user prefix (already suffix-only).
        """
        prefix = "dingtalk:sw:"
        if not webhook_key.startswith(prefix):
            return None
        ident = webhook_key[len(prefix) :]
        # If ident contains '_', it might be user_id + suffix
        underscore_idx = ident.rfind("_")
        if underscore_idx < 0:
            return None  # Already suffix-only
        suffix = ident[underscore_idx + 1 :]
        if not suffix:
            return None
        return f"{prefix}{suffix}"

    async def _load_session_webhook_entry(
        self,
        webhook_key: str,
    ) -> Optional[Dict[str, Any]]:
        """Load the full webhook entry dict from store (memory then disk).

        Returns None if not found or if the webhook is expired.
        Falls back to suffix-only key for backward compatibility with
        old DM entries and group chat entries.
        """
        if not webhook_key:
            return None
        async with self._session_webhook_lock:
            raw = self._session_webhook_store.get(webhook_key)
            source = "memory"

            if raw is None:
                self._load_session_webhook_store_from_disk()
                raw = self._session_webhook_store.get(webhook_key)
                source = "disk"

            # Fallback: try suffix-only key (old DM data / group chat)
            if raw is None:
                fallback_key = self._suffix_only_webhook_key(webhook_key)
                if fallback_key:
                    raw = self._session_webhook_store.get(fallback_key)
                    if raw is not None:
                        source = f"fallback({fallback_key})"

            if raw is not None:
                entry = raw if isinstance(raw, dict) else {"webhook": raw}
                logger.info(
                    "dingtalk _load_session_webhook_entry hit(%s): "
                    "webhook_key=%s session_from_url=%s",
                    source,
                    webhook_key,
                    session_param_from_webhook_url(
                        entry.get("webhook", ""),
                    ),
                )
                return entry

            logger.info(
                "dingtalk _load_session_webhook_entry miss: webhook_key=%s",
                webhook_key,
            )
            return None

    @staticmethod
    def _resolve_open_api_params(
        meta: Dict[str, Any],
        webhook_entry: Optional[Dict[str, Any]],
    ) -> Dict[str, str]:
        """Extract conversation_id / conversation_type / sender_staff_id.

        Merges values from *meta* (higher priority) and *webhook_entry*
        (lower priority) so that callers don't repeat the same pattern.
        """
        entry = webhook_entry or {}
        return {
            "conversation_id": (
                meta.get("conversation_id", "")
                or entry.get("conversation_id", "")
            ),
            "conversation_type": (
                meta.get("conversation_type", "")
                or entry.get("conversation_type", "")
            ),
            "sender_staff_id": (
                meta.get("sender_staff_id", "")
                or entry.get("sender_staff_id", "")
            ),
        }

    def _get_session_webhook(
        self,
        meta: Optional[Dict[str, Any]],
    ) -> Optional[str]:
        """Get sessionWebhook from meta."""
        if not meta:
            return None
        return meta.get("session_webhook") or meta.get("sessionWebhook")

    def _parts_to_single_text(
        self,
        parts: List[OutgoingContentPart],
        bot_prefix: str = "",
    ) -> str:
        """
        Build one reply text from parts.
        """
        text_parts: List[str] = []
        for p in parts:
            t = getattr(p, "type", None)
            if t == ContentType.TEXT and getattr(p, "text", None):
                text_parts.append(p.text or "")
            elif t == ContentType.REFUSAL and getattr(p, "refusal", None):
                text_parts.append(p.refusal or "")
        body = "\n".join(text_parts) if text_parts else ""
        if bot_prefix and body:
            body = bot_prefix + "  " + body
        return body

    async def _send_via_session_webhook(
        self,
        session_webhook: str,
        body: str,
        bot_prefix: str = "",
        at_user_ids: Optional[List[str]] = None,
        at_dingtalk_ids: Optional[List[str]] = None,
    ) -> bool:
        """Send text via DingTalk sessionWebhook. Returns True on success.

        When ``at_user_ids`` or ``at_dingtalk_ids`` is provided, the
        ``at`` field is added so mentioned users get a push notification.
        The @mention text is also prepended to the message body (DingTalk
        requires both). Oversized bodies are split and each chunk is sent
        as markdown; ``at`` is attached only to the first chunk.
        """
        text = (bot_prefix + "  " + body) if body else bot_prefix

        # Build at payload and prepend @mention text
        at_payload: Optional[Dict[str, Any]] = None
        if at_user_ids or at_dingtalk_ids:
            at_payload = {}
            mentions = []
            if at_user_ids:
                at_payload["atUserIds"] = at_user_ids
                mentions.extend(f"@{uid}" for uid in at_user_ids)
            if at_dingtalk_ids:
                at_payload["atDingtalkIds"] = at_dingtalk_ids
                mentions.extend(f"@{did}" for did in at_dingtalk_ids)
            text = " ".join(mentions) + "\n" + text

        for index, chunk in enumerate(_markdown_chunks(text)):
            norm = dingtalk_markdown.normalize_dingtalk_markdown(chunk)
            payload: Dict[str, Any] = {
                "msgtype": "markdown",
                "markdown": {
                    "title": f"💬{norm[:10]}...",
                    "text": norm,
                },
            }
            if index == 0 and at_payload:
                payload["at"] = at_payload
            sent = await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )
            if not sent:
                return False
        return True

    async def _send_via_open_api(
        self,
        body: str,
        conversation_id: str,
        conversation_type: str,
        sender_staff_id: str,
        bot_prefix: str = "",
    ) -> bool:
        """Send message via DingTalk Open API as fallback when sessionWebhook
        is expired or unavailable.

        Uses robot_1_0 SDK:
        - org_group_send for groups
        - batch_send_oto for DMs

        Oversized bodies are split and each chunk is sent as
        ``sampleMarkdown`` (not ``sampleText``).
        """
        text = (bot_prefix + "  " + body) if body else bot_prefix
        is_group = conversation_type == "group"

        logger.info(
            "dingtalk _send_via_open_api: is_group=%s conversation_id=%s "
            "sender_staff_id=%s text_len=%s",
            is_group,
            conversation_id,
            sender_staff_id,
            len(text),
        )

        for chunk in _markdown_chunks(text):
            norm = dingtalk_markdown.normalize_dingtalk_markdown(chunk)
            msg_param = json.dumps(
                {"title": f"💬{norm[:10]}...", "text": norm},
            )
            sent = await self._send_robot_message(
                msg_key="sampleMarkdown",
                msg_param=msg_param,
                conversation_id=conversation_id,
                is_group=is_group,
                sender_staff_id=sender_staff_id,
                caller="_send_via_open_api",
            )
            if not sent:
                return False
        return True

    async def _try_open_api_fallback(
        self,
        text: str,
        to_handle: str,
        meta: Optional[Dict[str, Any]],
    ) -> bool:
        """Try sending text via Open API using metadata from meta or store.

        Used when sessionWebhook is expired or send failed during
        cron agent task streaming (send_content_parts path).
        Returns True if Open API succeeded, False otherwise.
        """
        m = meta or {}
        webhook_entry: Optional[Dict[str, Any]] = None
        route = self._route_from_handle(to_handle)
        webhook_key = route.get("webhook_key")
        if webhook_key:
            async with self._session_webhook_lock:
                raw = self._session_webhook_store.get(webhook_key)
                if raw is None:
                    self._load_session_webhook_store_from_disk()
                    raw = self._session_webhook_store.get(webhook_key)
                # Fallback to suffix-only key
                if raw is None:
                    fallback_key = self._suffix_only_webhook_key(webhook_key)
                    if fallback_key:
                        raw = self._session_webhook_store.get(fallback_key)
                if raw is not None:
                    webhook_entry = (
                        raw if isinstance(raw, dict) else {"webhook": raw}
                    )

        params = self._resolve_open_api_params(m, webhook_entry)

        if not params["conversation_id"]:
            logger.warning(
                "dingtalk _try_open_api_fallback: no conversation_id, skip",
            )
            return False

        return await self._send_via_open_api(
            text,
            conversation_id=params["conversation_id"],
            conversation_type=params["conversation_type"],
            sender_staff_id=params["sender_staff_id"],
            bot_prefix="",
        )

    async def _resolve_open_api_params_from_handle(
        self,
        to_handle: str,
        meta: Optional[Dict[str, Any]],
    ) -> Dict[str, str]:
        """Resolve Open API params from to_handle and meta (async).

        Uses _load_session_webhook_entry for thread-safe access with
        locking and disk-loading fallback.
        """
        m = meta or {}
        route = self._route_from_handle(to_handle)
        webhook_key: str = route.get("webhook_key", "")
        webhook_entry = await self._load_session_webhook_entry(webhook_key)
        return self._resolve_open_api_params(m, webhook_entry)

    async def _send_media_part_via_open_api(
        self,
        part: OutgoingContentPart,
        conversation_id: str,
        conversation_type: str,
        sender_staff_id: str,
    ) -> bool:
        """Upload and send one media part via DingTalk Open API.

        Supports image (sampleImageMsg) and file (sampleFile) message
        types. Falls back to sending a text placeholder if upload fails.
        """
        ptype = getattr(part, "type", None)
        upload_type = self._map_upload_type(part)
        if upload_type is None:
            return True

        default_name = {
            "image": "image.png",
            "voice": "audio.amr",
            "video": "video.mp4",
            "file": "file.bin",
        }.get(upload_type, "file.bin")
        filename, ext = self._guess_filename_and_ext(
            part,
            default=default_name,
        )

        # Resolve URL from part attributes
        url = (
            getattr(part, "file_url", None)
            or getattr(part, "image_url", None)
            or getattr(part, "video_url", None)
            or ""
        )
        if not url and ptype == ContentType.AUDIO:
            data_attr = getattr(part, "data", None)
            if isinstance(data_attr, str) and (
                data_attr.startswith("http") or data_attr.startswith("file:")
            ):
                url = data_attr
        url = (url or "").strip() if isinstance(url, str) else ""

        # For images with public HTTP URLs, send directly via sampleImageMsg
        if upload_type == "image" and self._is_public_http_url(url):
            return await self._send_open_api_message(
                msg_key="sampleImageMsg",
                msg_param={"photoURL": url},
                conversation_id=conversation_id,
                conversation_type=conversation_type,
                sender_staff_id=sender_staff_id,
            )

        # Load bytes from base64 or URL
        data: Optional[bytes] = None
        raw_b64 = None
        if (
            isinstance(url, str)
            and url.startswith("data:")
            and "base64," in url
        ):
            raw_b64 = url
            url = ""
        if not raw_b64:
            raw_b64 = getattr(part, "base64", None)

        if raw_b64:
            if isinstance(raw_b64, str) and raw_b64.startswith("data:"):
                data, _ = parse_data_url(raw_b64)
            else:
                data = base64.b64decode(raw_b64, validate=False)
        if not data and url:
            data = await self._fetch_bytes_from_url(url)

        if not data:
            logger.warning(
                "dingtalk _send_media_part_via_open_api: no data, type=%s",
                ptype,
            )
            return False

        # Upload to get media_id
        effective_upload_type = upload_type
        if effective_upload_type == "voice":
            effective_upload_type = "file"
        if effective_upload_type == "video" and ext not in ("mp4",):
            effective_upload_type = "file"

        media_id = await self._upload_media(
            data,
            effective_upload_type,
            filename=filename,
        )
        if not media_id:
            logger.warning(
                "dingtalk _send_media_part_via_open_api: upload failed, "
                "type=%s",
                ptype,
            )
            return False

        # Send via Open API with appropriate msgKey
        # Note: sampleImageMsg does not support mediaId, so we send as
        # sampleFile for all media types including images.
        return await self._send_open_api_message(
            msg_key="sampleFile",
            msg_param={
                "mediaId": media_id,
                "fileName": filename,
                "fileType": ext,
            },
            conversation_id=conversation_id,
            conversation_type=conversation_type,
            sender_staff_id=sender_staff_id,
        )

    async def _send_open_api_message(
        self,
        *,
        msg_key: str,
        msg_param: Dict[str, Any],
        conversation_id: str,
        conversation_type: str,
        sender_staff_id: str,
    ) -> bool:
        """Send a single message via DingTalk Open API with given msgKey."""
        is_group = conversation_type == "group"
        return await self._send_robot_message(
            msg_key=msg_key,
            msg_param=json.dumps(msg_param),
            conversation_id=conversation_id,
            is_group=is_group,
            sender_staff_id=sender_staff_id,
            caller="_send_open_api_message",
        )

    async def _generate_video_cover_media_id(self) -> Optional[str]:
        """Generate and upload a placeholder cover image for video.

        Creates a simple 640x360 dark solid color PNG using Pillow.
        Returns the media_id of the uploaded cover image.
        """
        try:
            from PIL import Image

            import io

            img = Image.new("RGB", (640, 360), color=(45, 45, 48))
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            png_data = buf.getvalue()

            media_id = await self._upload_media(
                png_data,
                "image",
                filename="video_cover.png",
                content_type="image/png",
            )
            return media_id
        except (TimeoutError, aiohttp.ClientConnectionError):
            raise
        except Exception:
            logger.exception(
                "dingtalk _generate_video_cover_media_id failed",
            )
            return None

    async def _get_session_webhook_for_send(
        self,
        to_handle: str,
        meta: Optional[Dict[str, Any]],
    ) -> Optional[str]:
        """Resolve session_webhook for sending. Prefer current request's
        webhook (meta); only use store for proactive send (e.g. cron).
        When this is a reply to a user message (meta has conversation_id)
        and meta has no session_webhook, do not fall back to store so we
        never use a stale/expired webhook.
        """
        m = meta or {}
        webhook = m.get("session_webhook") or m.get("sessionWebhook")
        if webhook:
            logger.info(
                "dingtalk _get_session_webhook_for_send: to_handle=%s "
                "source=meta session_from_url=%s",
                to_handle[:40] if to_handle else "",
                session_param_from_webhook_url(webhook),
            )
            return webhook
        route = self._route_from_handle(to_handle)
        webhook = route.get("session_webhook")
        if webhook:
            logger.info(
                "dingtalk _get_session_webhook_for_send: to_handle=%s "
                "source=route session_from_url=%s",
                to_handle[:40] if to_handle else "",
                session_param_from_webhook_url(webhook),
            )
            return webhook
        # Current-request context but no webhook in meta: do not use store
        # (could be expired after long idle).
        if m.get("conversation_id"):
            logger.info(
                "dingtalk _get_session_webhook_for_send: to_handle=%s "
                "current request has no session_webhook, skip store",
                to_handle[:40] if to_handle else "",
            )
            return None
        key = route.get("webhook_key")
        if key:
            webhook = await self._load_session_webhook(key)
            if webhook:
                logger.info(
                    "dingtalk _get_session_webhook_for_send: to_handle=%s "
                    "source=store webhook_key=%s",
                    to_handle[:40] if to_handle else "",
                    key,
                )
            return webhook
        logger.info(
            "dingtalk _get_session_webhook_for_send: to_handle=%s source=none",
            to_handle[:40] if to_handle else "",
        )
        return None

    def _map_upload_type(self, part: OutgoingContentPart) -> Optional[str]:
        """
        Map OutgoingContentPart type to DingTalk media/upload type.
        DingTalk upload type must be one of: image | voice | video | file
        """
        ptype = getattr(part, "type", None)
        if ptype in (ContentType.TEXT, ContentType.REFUSAL, None):
            return None  # no upload
        if ptype == ContentType.IMAGE:
            return "image"
        if ptype == ContentType.AUDIO:
            return "voice"
        if ptype == ContentType.VIDEO:
            return "video"
        if ptype == ContentType.FILE:
            return "file"
        return "file"

    async def _send_media_part_via_webhook(
        self,
        session_webhook: str,
        part: OutgoingContentPart,
    ) -> bool:
        """Upload and send one media part via session webhook."""
        ptype = getattr(part, "type", None)
        upload_type = self._map_upload_type(part)

        logger.info(
            "dingtalk _send_media_part_via_webhook: type=%s upload_type=%s",
            ptype,
            upload_type,
        )

        # text/auto/refusal: no-op here (text is handled elsewhere)
        if upload_type is None:
            return True

        # ---------- image special-case: if public picURL, send directly ------
        if upload_type == "image":
            url = getattr(part, "image_url", None) or ""
            url = (url or "").strip() if isinstance(url, str) else ""
            if self._is_public_http_url(url):
                payload = {"msgtype": "image", "image": {"picURL": url}}
                return await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )
            # else: fallthrough to upload-by-bytes then send as file
            # (your existing fallback)

        # ---------- decide filename/ext ----------
        default_name = {
            "image": "image.png",
            "voice": "audio.amr",
            "video": "video.mp4",
            "file": "file.bin",
        }.get(upload_type, "file.bin")
        filename, ext = self._guess_filename_and_ext(
            part,
            default=default_name,
        )
        if upload_type == "video" and ext not in ("mp4",):
            upload_type = "file"
        elif upload_type == "voice":
            upload_type = "file"

        # ---------- if already has media id ----------
        # for file you used file_id;
        # keep compatibility but also accept media_id
        media_id = (
            getattr(part, "media_id", None)
            or getattr(part, "mediaId", None)
            or getattr(part, "file_id", None)
        )
        if media_id:
            media_id = str(media_id).strip()
            if not media_id:
                return False

            if upload_type == "image":
                # Use markdown with media_id for inline image preview
                payload = {
                    "msgtype": "markdown",
                    "markdown": {
                        "title": filename or "image",
                        "text": f"![{filename or 'image'}]({media_id})",
                    },
                }
                ok = await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )
                if ok:
                    return True
                # Fallback to file card if markdown fails
                payload = {
                    "msgtype": "file",
                    "file": {
                        "mediaId": media_id,
                        "fileType": ext,
                        "fileName": filename,
                    },
                }
                return await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )

            if upload_type == "voice":
                # sendBySession returns 400105 "unsupported msgtype" for voice.
                payload = {
                    "msgtype": "file",
                    "file": {
                        "mediaId": media_id,
                        "fileType": ext,
                        "fileName": filename,
                    },
                }
                return await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )

            if upload_type == "video":
                pic_media_id = (
                    getattr(part, "pic_media_id", None)
                    or getattr(part, "picMediaId", None)
                    or ""
                )
                pic_media_id = (pic_media_id or "").strip()
                if pic_media_id:
                    duration = getattr(part, "duration", None)
                    if duration is None:
                        duration = 1
                    payload = {
                        "msgtype": "video",
                        "video": {
                            "videoMediaId": media_id,
                            "videoType": ext or "mp4",
                            "duration": str(int(duration)),
                            "picMediaId": pic_media_id,
                        },
                    }
                    ok = await self._send_payload_via_session_webhook(
                        session_webhook,
                        payload,
                    )
                    if ok:
                        return True
                # No picMediaId or video send failed: send as file
                payload = {
                    "msgtype": "file",
                    "file": {
                        "mediaId": media_id,
                        "fileType": ext,
                        "fileName": filename,
                    },
                }
                return await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )

            # file
            payload = {
                "msgtype": "file",
                "file": {
                    "mediaId": media_id,
                    "fileType": ext,
                    "fileName": filename,
                },
            }
            return await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )

        # ---------- load bytes from base64 or url ----------
        data: Optional[bytes] = None
        url = (
            getattr(part, "file_url", None)
            or getattr(part, "image_url", None)
            or getattr(part, "video_url", None)
            or ""
        )
        # AudioContent stores URL in "data" (renderer _blocks_to_parts)
        if not url and ptype == ContentType.AUDIO:
            data_attr = getattr(part, "data", None)
            if isinstance(data_attr, str) and (
                data_attr.startswith("http") or data_attr.startswith("file:")
            ):
                url = data_attr
        url = (url or "").strip() if isinstance(url, str) else ""
        raw_b64 = None
        if (
            isinstance(url, str)
            and url.startswith("data:")
            and "base64," in url
        ):
            raw_b64 = url
            url = ""
        if not raw_b64:
            raw_b64 = getattr(part, "base64", None)

        if raw_b64:
            if isinstance(raw_b64, str) and raw_b64.startswith("data:"):
                data, mime = parse_data_url(raw_b64)
                content_type_for_upload = (
                    mime or getattr(part, "mime_type", None) or ""
                ).strip()
                if mime and not getattr(part, "filename", None):
                    ext_guess = (mimetypes.guess_extension(mime) or "").lstrip(
                        ".",
                    ) or ""
                    if ext_guess:
                        filename = f"upload.{ext_guess}"
                        ext = ext_guess
            else:
                data = base64.b64decode(raw_b64, validate=False)
                content_type_for_upload = (
                    getattr(part, "mime_type", None) or ""
                ).strip()
        else:
            content_type_for_upload = (
                getattr(part, "mime_type", None) or ""
            ).strip()
        if not data and url:
            data = await self._fetch_bytes_from_url(url)

        if not data:
            logger.warning(
                "dingtalk media part: no data to upload (empty file?), "
                "type=%s",
                ptype,
            )
            return False

        # ---------- upload ----------
        media_id = await self._upload_media(
            data,
            upload_type,  # image | voice | video | file
            filename=filename,
            content_type=content_type_for_upload or None,
        )
        if not media_id:
            return False

        # ---------- send ----------
        if upload_type == "image":
            # Use markdown with media_id for inline image preview
            payload = {
                "msgtype": "markdown",
                "markdown": {
                    "title": filename or "image",
                    "text": f"![{filename or 'image'}]({media_id})",
                },
            }
            ok = await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )
            if ok:
                return True
            # Fallback to file card if markdown fails
            payload = {
                "msgtype": "file",
                "file": {
                    "mediaId": media_id,
                    "fileType": ext,
                    "fileName": filename,
                },
            }
            return await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )

        if upload_type == "voice":
            # sendBySession returns 400105 for voice; send as file.
            payload = {
                "msgtype": "file",
                "file": {
                    "mediaId": media_id,
                    "fileType": ext,
                    "fileName": filename,
                },
            }
            return await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )

        if upload_type == "video":
            pic_media_id = (
                getattr(part, "pic_media_id", None)
                or getattr(part, "picMediaId", None)
                or ""
            ).strip()
            if not pic_media_id:
                # Auto-generate placeholder cover image
                pic_media_id = (
                    await self._generate_video_cover_media_id()
                ) or ""
            if pic_media_id:
                duration = getattr(part, "duration", None)
                if duration is None:
                    duration = 1
                payload = {
                    "msgtype": "video",
                    "video": {
                        "videoMediaId": media_id,
                        "videoType": ext or "mp4",
                        "duration": str(int(duration)),
                        "picMediaId": pic_media_id,
                    },
                }
                ok = await self._send_payload_via_session_webhook(
                    session_webhook,
                    payload,
                )
                if ok:
                    return True
            # Fallback to file card if video send fails or no cover
            payload = {
                "msgtype": "file",
                "file": {
                    "mediaId": media_id,
                    "fileType": ext,
                    "fileName": filename,
                },
            }
            return await self._send_payload_via_session_webhook(
                session_webhook,
                payload,
            )

        payload = {
            "msgtype": "file",
            "file": {
                "mediaId": media_id,
                "fileType": ext,
                "fileName": filename,
            },
        }
        return await self._send_payload_via_session_webhook(
            session_webhook,
            payload,
        )

    @owned_io
    async def send_content_parts(
        self,
        to_handle: str,
        parts: List[OutgoingContentPart],
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Build one body from parts and send via webhook or Open API.

        When session_webhook is available, sends text then image/file
        messages (upload media first for image/file).
        """
        if not parts:
            return
        api_send = self._api_send_delivery_errors(meta)
        text_parts = []
        media_parts: List[OutgoingContentPart] = []
        for p in parts:
            t = getattr(p, "type", None) or (
                p.get("type") if isinstance(p, dict) else None
            )
            text_val = getattr(p, "text", None) or (
                p.get("text") if isinstance(p, dict) else None
            )
            refusal_val = getattr(p, "refusal", None) or (
                p.get("refusal") if isinstance(p, dict) else None
            )
            if t == ContentType.TEXT and text_val:
                text = str(text_val)
                if text.strip():
                    text_parts.append(text)
            elif t == ContentType.REFUSAL and refusal_val:
                refusal = str(refusal_val)
                if refusal.strip():
                    text_parts.append(refusal)
            elif t == ContentType.IMAGE:
                media_parts.append(p)
            elif t == ContentType.FILE:
                media_parts.append(p)
            elif t == ContentType.VIDEO:
                media_parts.append(p)
            elif t == ContentType.AUDIO:
                media_parts.append(p)
        body = "\n".join(text_parts) if text_parts else ""
        prefix = (meta or {}).get("bot_prefix", "") or ""
        if prefix and body.strip():
            body = prefix + "  " + body
        if not body.strip() and not media_parts:
            logger.info(
                "dingtalk send_content_parts: skip empty content "
                "to_handle=%s",
                to_handle[:40] if to_handle else "",
            )
            return
        session_webhook = await self._get_session_webhook_for_send(
            to_handle,
            meta,
        )
        logger.info(
            "dingtalk send_content_parts: to_handle=%s has_webhook=%s "
            "text_parts=%s media_parts=%s",
            to_handle[:40] if to_handle else "",
            bool(session_webhook),
            len(text_parts),
            len(media_parts),
        )

        # ---------- AI Card path (cron / proactive sends) ----------
        if self._cron_ai_card_enabled() and body.strip():
            params = await self._resolve_open_api_params_from_handle(
                to_handle,
                meta,
            )
            conversation_id = params["conversation_id"]
            if conversation_id:
                card_meta = {
                    "conversation_id": conversation_id,
                    "conversation_type": params["conversation_type"],
                    "sender_staff_id": params["sender_staff_id"],
                    "is_group": params["conversation_type"] == "group",
                }
                try:
                    card = await self._create_ai_card(
                        conversation_id,
                        meta=card_meta,
                        inbound=False,
                        force=True,
                    )
                    if card:
                        await self._stream_ai_card(
                            card,
                            body.strip(),
                            finalize=True,
                        )
                        logger.info(
                            "dingtalk send_content_parts: "
                            "AI card sent ok, conversation_id=%s",
                            conversation_id,
                        )
                        # Send media parts separately via Open API
                        for i, part in enumerate(media_parts):
                            logger.info(
                                "dingtalk send_content_parts: "
                                "sending media part %s/%s via Open API "
                                "(AI card path) type=%s",
                                i + 1,
                                len(media_parts),
                                getattr(part, "type", None),
                            )
                            await self._send_media_part_via_open_api(
                                part,
                                conversation_id=conversation_id,
                                conversation_type=params["conversation_type"],
                                sender_staff_id=params["sender_staff_id"],
                            )
                        return
                except (TimeoutError, aiohttp.ClientConnectionError):
                    raise
                except Exception:
                    logger.exception(
                        "dingtalk send_content_parts: AI card failed, "
                        "falling back to webhook/Open API",
                    )

        if session_webhook and (body.strip() or media_parts):
            text_ok = True
            if body.strip():
                logger.info("dingtalk send_content_parts: sending text body")
                text_ok = await self._send_via_session_webhook(
                    session_webhook,
                    body.strip(),
                    bot_prefix="",
                )
            if not text_ok:
                await self._invalidate_session_webhook(to_handle)
                logger.warning(
                    "dingtalk send_content_parts: webhook send failed, "
                    "trying Open API fallback",
                )
                fallback_ok = await self._try_open_api_fallback(
                    body.strip(),
                    to_handle,
                    meta,
                )
                if fallback_ok:
                    return
                self._raise_delivery_error_if_api_send(
                    api_send,
                    "DingTalk send failed via sessionWebhook and "
                    "Open API fallback",
                )
            for i, part in enumerate(media_parts):
                logger.info(
                    "dingtalk send_content_parts: "
                    "sending media part %s/%s type=%s",
                    i + 1,
                    len(media_parts),
                    getattr(part, "type", None),
                )
                ok = await self._send_media_part_via_webhook(
                    session_webhook,
                    part,
                )
                logger.info(
                    "dingtalk send_content_parts: media part %s result=%s",
                    i + 1,
                    ok,
                )
                if not ok:
                    # Webhook media send failed: fallback to Open API
                    logger.warning(
                        "dingtalk send_content_parts: webhook media send "
                        "failed for part %s, trying Open API fallback",
                        i + 1,
                    )
                    params = await self._resolve_open_api_params_from_handle(
                        to_handle,
                        meta,
                    )
                    if params["conversation_id"]:
                        await self._send_media_part_via_open_api(
                            part,
                            conversation_id=params["conversation_id"],
                            conversation_type=params["conversation_type"],
                            sender_staff_id=params["sender_staff_id"],
                        )
            return
        # Fallback path: no session_webhook available.
        # Try sending media parts via Open API (upload + rich message)
        # instead of degrading to plain-text file paths.
        if media_parts:
            params = await self._resolve_open_api_params_from_handle(
                to_handle,
                meta,
            )
            if params["conversation_id"]:
                # Send text body first via Open API if present
                if body.strip():
                    text_ok = await self._send_via_open_api(
                        body.strip(),
                        conversation_id=params["conversation_id"],
                        conversation_type=params["conversation_type"],
                        sender_staff_id=params["sender_staff_id"],
                        bot_prefix="",
                    )
                    if not text_ok:
                        logger.warning(
                            "dingtalk send_content_parts: Open API text "
                            "send failed",
                        )
                        self._raise_delivery_error_if_api_send(
                            api_send,
                            "DingTalk send failed: Open API text "
                            "send failed",
                        )
                for i, part in enumerate(media_parts):
                    logger.info(
                        "dingtalk send_content_parts: "
                        "sending media part %s/%s via Open API type=%s",
                        i + 1,
                        len(media_parts),
                        getattr(part, "type", None),
                    )
                    await self._send_media_part_via_open_api(
                        part,
                        conversation_id=params["conversation_id"],
                        conversation_type=params["conversation_type"],
                        sender_staff_id=params["sender_staff_id"],
                    )
                return
            logger.warning(
                "dingtalk send_content_parts: no webhook and no "
                "conversation_id, skipping %s media part(s)",
                len(media_parts),
            )

        if body.strip():
            await self.send(to_handle, body.strip(), meta)

    @staticmethod
    def _api_send_delivery_errors(meta: Optional[Dict[str, Any]]) -> bool:
        """Return whether API send delivery failures should propagate."""
        if not meta:
            return False
        return bool(meta.get("_api_send"))

    @staticmethod
    def _raise_delivery_error_if_api_send(
        api_send: bool,
        message: str,
    ) -> None:
        if api_send:
            raise ChannelError(
                channel_name="dingtalk",
                message=message,
            )

    def _ai_card_enabled(self) -> bool:
        return (
            self.message_type == "card"
            and bool(self.card_template_id)
            and bool(self.robot_code)
        )

    def _cron_ai_card_enabled(self) -> bool:
        """Check if AI Card is enabled for cron/proactive sends."""
        return (
            self.cron_message_type == "card"
            and bool(self.card_template_id)
            and bool(self.robot_code)
        )

    def _build_ai_card_initial_text(self) -> str:
        return self.bot_prefix + AI_CARD_PROCESSING_TEXT

    async def _save_active_cards(self) -> None:
        async with self._active_cards_lock:
            self._card_store.save(self._active_cards)

    async def _mark_card_failed(self, conversation_id: str) -> None:
        async with self._active_cards_lock:
            card = self._active_cards.get(conversation_id)
            if card:
                card.state = FAILED
                card.last_updated = int(time.time() * 1000)
                self._active_cards.pop(conversation_id, None)
            self._card_store.save(self._active_cards)

    async def _recover_active_cards(self) -> None:
        if not self._ai_card_enabled() or self._card_sdk is None:
            return
        records = self._card_store.load()
        if not records:
            return
        token = await self._get_access_token()
        for item in records:
            state = str(item.get("state") or "")
            if state in (FINISHED, FAILED):
                continue
            conversation_id = item.get("conversation_id") or ""
            card_id = item.get("card_instance_id") or f"card_{uuid4()}"
            if not conversation_id:
                continue
            card = ActiveAICard(
                card_instance_id=card_id,
                access_token=token,
                conversation_id=conversation_id,
                account_id=item.get("account_id") or "default",
                store_path=str(self._card_store.path),
                created_at=int(
                    item.get("created_at") or int(time.time() * 1000),
                ),
                last_updated=int(
                    item.get("last_updated") or int(time.time() * 1000),
                ),
                state=state or PROCESSING,
                last_streamed_content="",
            )
            async with self._active_cards_lock:
                self._active_cards[conversation_id] = card
            try:
                await self._stream_ai_card(
                    card,
                    AI_CARD_RECOVERY_FINAL_TEXT,
                    finalize=True,
                )
            except (TimeoutError, aiohttp.ClientConnectionError):
                await self._save_active_cards()
            except Exception:
                logger.exception("dingtalk ai card recovery finalize failed")
                await self._mark_card_failed(conversation_id)

    @owned_io
    async def send(
        self,
        to_handle: str,
        text: str,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Proactive send for DingTalk via stored sessionWebhook.

        Supports:
        1) meta["session_webhook"] or meta["sessionWebhook"]: direct url
        2) to_handle: dingtalk:sw:<sender> (stored) or http(s) url
        3) Open API fallback when webhook is expired or unavailable.

        If strict delivery is requested and no webhook/Open API target is
        available, raises ChannelError so explicit callers do not report
        delivery success for an unreachable target.
        """
        if not self.enabled:
            return
        meta = meta or {}
        api_send = self._api_send_delivery_errors(meta)

        if self._http is None:
            logger.warning(
                "DingTalkChannel.send: HTTP session is not initialized",
            )
            self._raise_delivery_error_if_api_send(
                api_send,
                "DingTalk HTTP session is not initialized",
            )
            return

        # direct webhook provided in meta (current request, always valid)
        session_webhook = meta.get("session_webhook") or meta.get(
            "sessionWebhook",
        )
        webhook_entry: Optional[Dict[str, Any]] = None

        if not session_webhook:
            route = self._route_from_handle(to_handle)
            session_webhook = route.get("session_webhook")
            if not session_webhook:
                webhook_key = route.get("webhook_key")
                if webhook_key:
                    webhook_entry = await self._load_session_webhook_entry(
                        webhook_key,
                    )
                    if webhook_entry is not None:
                        session_webhook = webhook_entry.get("webhook")

        if not session_webhook:
            # No valid webhook: try Open API fallback directly
            logger.info(
                "DingTalkChannel.send: no sessionWebhook for to_handle=%s, "
                "trying Open API fallback",
                to_handle,
            )
            params = self._resolve_open_api_params(
                meta,
                webhook_entry,
            )
            if not params["conversation_id"]:
                logger.warning(
                    "DingTalkChannel.send: no sessionWebhook and no "
                    "conversation_id for to_handle=%s. User must have "
                    "chatted with the bot first.",
                    to_handle,
                )
                self._raise_delivery_error_if_api_send(
                    api_send,
                    "DingTalk send failed: no sessionWebhook or "
                    "conversation_id available",
                )
                return
            ok = await self._send_via_open_api(
                text,
                conversation_id=params["conversation_id"],
                conversation_type=params["conversation_type"],
                sender_staff_id=params["sender_staff_id"],
                bot_prefix="",
            )
            if not ok:
                self._raise_delivery_error_if_api_send(
                    api_send,
                    "DingTalk Open API send failed",
                )
            return

        logger.info(
            "DingTalkChannel.send to_handle=%s len=%s",
            to_handle,
            len(text),
        )

        # Caller (send_content_parts) already prepends bot_prefix to text.
        success = await self._send_via_session_webhook(
            session_webhook,
            text,
            bot_prefix="",
        )
        if success:
            return

        # Webhook send failed (possibly expired): invalidate and try fallback
        await self._invalidate_session_webhook(to_handle)
        logger.warning(
            "DingTalkChannel.send: sessionWebhook send failed, "
            "trying Open API fallback for to_handle=%s",
            to_handle,
        )
        params = self._resolve_open_api_params(
            meta,
            webhook_entry,
        )

        if not params["conversation_id"]:
            logger.warning(
                "DingTalkChannel.send: Open API fallback skipped: "
                "no conversation_id available",
            )
            self._raise_delivery_error_if_api_send(
                api_send,
                "DingTalk send failed: sessionWebhook failed and "
                "no conversation_id is available",
            )
            return

        ok = await self._send_via_open_api(
            text,
            conversation_id=params["conversation_id"],
            conversation_type=params["conversation_type"],
            sender_staff_id=params["sender_staff_id"],
            bot_prefix="",
        )
        if not ok:
            self._raise_delivery_error_if_api_send(
                api_send,
                "DingTalk Open API send failed",
            )

    async def _fetch_and_download_media(
        self,
        *,
        download_code: str,
        robot_code: str,
        filename_hint: str = "file.bin",
    ) -> Optional[str]:
        """Get download URL from API, save to local, return path."""
        url = await self._get_message_file_download_url(
            download_code=download_code,
            robot_code=robot_code,
        )
        if not url:
            return None
        key = hashlib.md5(
            (download_code + robot_code).encode(),
        ).hexdigest()[:24]
        return await self._download_media_to_local(
            url,
            key,
            filename_hint,
        )

    def _guess_filename_and_ext(
        self,
        part: OutgoingContentPart,
        default: str,
    ) -> tuple[str, str]:
        """
        Return (filename, ext) where ext has no dot.
        Tries: part.filename -> url path basename -> default
        """
        filename = (getattr(part, "filename", None) or "").strip()

        if not filename:
            # AudioContent stores its URL in "data" instead of file_url
            data_attr = getattr(part, "data", None)
            audio_url = (
                data_attr
                if isinstance(data_attr, str)
                and (
                    data_attr.startswith("http")
                    or data_attr.startswith("file:")
                )
                else None
            )
            url = (
                getattr(part, "file_url", None)
                or getattr(part, "image_url", None)
                or getattr(part, "video_url", None)
                or audio_url
                or ""
            )
            url = (url or "").strip() if isinstance(url, str) else ""
            if url:
                try:
                    path = urlparse(url).path
                    base = unquote(os.path.basename(path))
                    if base:
                        filename = base
                except (TimeoutError, aiohttp.ClientConnectionError):
                    raise
                except Exception:
                    pass

        if not filename:
            filename = default

        ext = ""
        if "." in filename:
            ext = filename.rsplit(".", 1)[-1].lower().strip()

        if not ext:
            # try from mime_type if provided
            mime = (
                getattr(part, "mime_type", None)
                or getattr(part, "content_type", None)
                or ""
            ).strip()
            if mime:
                guess = mimetypes.guess_extension(mime)  # like ".png"
                if guess:
                    ext = guess.lstrip(".").lower()

        if not ext:
            ext = (
                default.rsplit(".", 1)[-1].lower() if "." in default else "bin"
            )

        # normalize common cases
        if ext == "jpeg":
            ext = "jpg"

        return filename, ext

    def _is_public_http_url(self, s: Optional[str]) -> bool:
        if not s or not isinstance(s, str):
            return False
        s = s.strip()
        return s.startswith("http://") or s.startswith("https://")

    def _try_accept_message(self, msg_id):
        # The shared Driver admits and deduplicates only through the host ACK.
        return True

    async def start_stream(self, meta, text, *, on_created=None):
        card = await self._create_ai_card(
            str(meta.get("conversation_id") or ""),
            meta=meta,
            on_created=on_created,
        )
        if card is None:
            raise ChannelError(
                channel_name="dingtalk",
                message="Card unavailable",
            )
        await self._stream_ai_card(card, text)
        return {
            "card_id": card.card_instance_id,
            "conversation_id": card.conversation_id,
            "unsettled": "false",
        }

    async def update_stream(self, resource, text, sequence, *, final):
        card_id = resource["card_id"]
        card = self._active_cards.get(card_id)
        if card is None:
            now = int(time.time() * 1000)
            card = ActiveAICard(
                card_id,
                await self._get_access_token(),
                resource["conversation_id"],
                "default",
                str(self._card_store.path),
                now,
                now,
                PROCESSING,
            )
            self._active_cards[card_id] = card
        if not final and text.strip() == card.last_streamed_content.strip():
            return True
        return await self._stream_ai_card(card, text, finalize=final)

    async def send_parts(
        self,
        to_handle,
        parts,
        meta,
        *,
        approval=None,
        on_created=None,
    ):
        """Compose proven helpers, accounting for every visible side effect."""
        webhook = meta.get("session_webhook") or ""
        body = self._parts_to_single_text(parts, meta.get("bot_prefix", ""))
        if approval:
            body += (
                f"\n/approval approve {approval.request_id}"
                f"\n/approval deny {approval.request_id}"
            )
        media = [
            p
            for p in parts
            if getattr(p, "type", None)
            not in {ContentType.TEXT, ContentType.REFUSAL}
        ]
        completed = 0
        try:
            inbound = bool(meta.get("message_id"))
            use_card = (
                self._ai_card_enabled()
                if inbound
                else self._cron_ai_card_enabled()
            )
            if use_card and body.strip() and meta.get("conversation_id"):
                card = await self._create_ai_card(
                    meta["conversation_id"],
                    meta=meta,
                    inbound=inbound,
                    force=True,
                    on_created=on_created,
                )
                if card:
                    completed += 1
                    if not await self._stream_ai_card(
                        card,
                        body,
                        finalize=True,
                    ):
                        raise TimeoutError("DingTalk card outcome is unknown")
                    body = ""
                    webhook = ""
            if body.strip():
                ok = (
                    await self._send_via_session_webhook(
                        webhook,
                        body,
                        at_user_ids=(
                            [meta["sender_staff_id"]]
                            if self.at_sender_on_reply
                            and meta.get("is_group")
                            and meta.get("sender_staff_id")
                            else None
                        ),
                        at_dingtalk_ids=(
                            [meta["sender_dingtalk_id"]]
                            if self.at_sender_on_reply
                            and meta.get("is_group")
                            and not meta.get("sender_staff_id")
                            and meta.get("sender_dingtalk_id")
                            else None
                        ),
                    )
                    if webhook
                    else False
                )
                if not ok:
                    if webhook:
                        await self._invalidate_session_webhook(to_handle)
                    ok = (
                        await self._send_via_open_api(
                            body,
                            meta.get("conversation_id", ""),
                            meta.get("conversation_type", ""),
                            meta.get("sender_staff_id", ""),
                        )
                        if meta.get("conversation_id")
                        else False
                    )
                if not ok:
                    raise ChannelError(
                        channel_name="dingtalk",
                        message="DingTalk send rejected",
                    )
                completed += 1
            for part in media:
                ok = (
                    await self._send_media_part_via_webhook(webhook, part)
                    if webhook
                    else False
                )
                if not ok and meta.get("conversation_id"):
                    ok = await self._send_media_part_via_open_api(
                        part,
                        meta["conversation_id"],
                        meta.get("conversation_type", ""),
                        meta.get("sender_staff_id", ""),
                    )
                if not ok:
                    raise ChannelError(
                        channel_name="dingtalk",
                        message="DingTalk media send rejected",
                    )
                completed += 1
        except ChannelError as exc:
            if completed:
                raise TimeoutError(
                    "DingTalk partial delivery outcome is unknown",
                ) from exc
            raise
